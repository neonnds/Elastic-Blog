var F = require('total.js');
var http = require('http');

F.http('debug');

console.log('****** Started ******');
