var max_delay = 3000; // longest update pause (in ms)
var processing_time = 0;
var last = null;
var convertTextTimer;
